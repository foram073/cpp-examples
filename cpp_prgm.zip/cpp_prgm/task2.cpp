#include <iostream>

using namespace std;

class mother
{
	public:
	void display()
	{
		cout << "In base class "<<endl;
	}
};

class daughter:public mother
{
	public:
	void display()
	{
		cout << "In derived class "<<endl;
	}
};

int main()
{
	daughter doll;
	doll.display();
	return 0;
}
