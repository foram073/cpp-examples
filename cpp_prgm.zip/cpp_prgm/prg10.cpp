// Program of Inheritance

#include <iostream>

using namespace std;

class shape	
{
	protected:
	int height;
	int width;
	public:
	void setwidth(int w)
	{
		width = w;
	}
	void setheight(int h)
	{
		height = h;
	}
};

class rectangle:public shape	
{
	public:
	int getarea()
	{
		return (height * width);
	}
};

int main()
{
	rectangle rect;	
	
	rect.setwidth(8);
	rect.setheight(10);
	
	cout<<"rectangle area "<<rect.getarea()<<endl;
	
	return 0;
}
