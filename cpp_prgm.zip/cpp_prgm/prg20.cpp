// Program on function overloaading of compile time polymorphism

#include <iostream>

using namespace std;
 
class printdata 
{
	public:
	void print(int i) 
	{
		cout << "Printing int " << i << endl;
	}
	void print(double  f) 
	{
		cout << "Printing float " << f << endl;
	}
	void print(char* c) 
	{
		cout << "Printing character " << c << endl;
	}
};

int main() 
{
	printdata pdt;
 
	pdt.print(5);
   
	pdt.print(500.263);
   
	pdt.print("Hello C++");
 
	return 0;
}
