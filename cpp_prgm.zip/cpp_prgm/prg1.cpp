// Basic program of class and objects

#include <iostream>
#include <string>

using namespace std;

class student
{
    public:
        string name;
        int roll_no;
};

int main()
{
    student std;
    std.name = "Foram";
    std.roll_no = 9;
    cout <<"Name : "<< std.name << endl <<"Roll No. : "<< std.roll_no << endl;
    return 0;
}

