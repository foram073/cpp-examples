#include <iostream>

using namespace std;

bool cal(int num)
{
	if(num >= 0)
	{
		return true;
	}
	if(num < 0)
	{
		return false;
	}
}

int main()
{
	int val;
	bool res;
	cout <<"Enter number ";
	cin >> val;
	res = cal(val);
	cout <<std::boolalpha <<"result is "<<res <<endl;
	
	return 0;
}
