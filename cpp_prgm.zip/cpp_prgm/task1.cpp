#include<iostream>

using namespace std;

class shape
{
	private:
	float height, width;
	
	public:
	shape(float h, float w)
	{
		height = h;
		width = w;
	}
	
	float getwidth()
	{
		return width;
	}
	float getheight()
	{
		return height;
	}
};

class rectangle: public shape
{
	public:
	rectangle(float height, float width):shape(height, width)
	{ 
	
	}
	float area()
	{
		return (getheight() * getwidth());
	}
};

class triangle: public shape
{
	public:
	triangle(float height, float width):shape(height, width)
	{ 
	
	}
	float area()
	{
		return (getheight() * getwidth()) /2;
	}
};

int main()
{
	rectangle rect(5.0,3.0);
	triangle tri(2.0,5.0);
	//rect.shape(8,10);
	//shape(2,5);
	cout<<"Area of rectangle "<<rect.area()<<endl;
	cout<<"Area of triangle "<<tri.area()<<endl;
	return 0;
}
