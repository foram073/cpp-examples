// program of parameterized constructor

#include <iostream>

using namespace std;

class employee
{
	public:
	int id;
	string name;
	float salary;
	employee(int i,string n,float s)
	{
		id = i;
		name = n;
		salary = s;
	}
	void display()
	{
		cout<<id<<" "<<name<<" "<<salary<<endl;
	}
};

int main()
{
	employee emp1(101,"abcd",24000);
	employee emp2(102,"efghi",35000);
	employee emp3(103,"xyzw",20000);
	emp1.display();
	emp2.display();
	emp3.display();
	return 0;
}
