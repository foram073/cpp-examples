#include <iostream>

using namespace std;

int main()
{
	int factorial(int);
	int fact, value;
	cout <<"Enter a number ";
	cin >> value;
	fact = factorial(value);
	cout <<"Factorial of a number is " <<fact <<endl;
	return 0;
}

int factorial(int num)
{
	if(num < 0)
	{
		return -1;
	}
	if(num == 0)
	{
		return 1;
	}
	else
	{
		return(num * factorial(num-1));
	}
}
