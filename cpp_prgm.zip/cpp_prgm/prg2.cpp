#include <iostream>

using namespace std;

int main()
{
	cout <<"Oh what" << endl <<"a happy day!" << endl <<"Oh yes," << endl <<"what a happy day!" << endl;
	return 0;
}
