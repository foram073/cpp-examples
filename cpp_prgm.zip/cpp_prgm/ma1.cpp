#include <iostream>
#include <string>

using namespace std;

class Student {
public: 
    int rollNo;
    string stdName;
    float marks;
};

int main()
{
    Student std1, std2;

    std1.rollNo = 1;
    std1.stdName = "abcd";
    std1.marks = 98.20;

    std2.rollNo = 2;
    std2.stdName = "efgh";
    std2.marks = 99.99;

    cout << "student 1" << "\n";
    cout << "Student's Roll No.: " << std1.rollNo << "\n";
    cout << "Student's Name: " << std1.stdName << "\n";
    cout << "Student's Percentage: " << std1.marks << "\n";

    cout << "student 2" << "\n";
    cout << "Student's Roll No.: " << std2.rollNo << "\n";
    cout << "Student's Name: " << std2.stdName << "\n";
    cout << "Student's Percentage: " << std2.marks << "\n";

    return 0;
}
