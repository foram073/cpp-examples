// Program of runtime polymorphism without virtual keyword

#include <iostream> 
   
using namespace std;    

class Animal 
{    
	public:    
	void eat()
	{      
		cout<<"Eating"<<endl;      
	}        
};     

class Dog: public Animal      
{      
	public:    
	void eat()      
	{           
		cout<<"Eating bicuits"<<endl;      
	}      
};    

int main() 
{    
	Dog d ;     
	d.eat();    
	return 0;    
} 
