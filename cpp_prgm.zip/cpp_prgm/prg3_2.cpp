#include <iostream>

using namespace std;

bool func(int val)
{
	while(1)
	{
		loop : cout <<"Enter number ";
		cin >> val;
		if(val < 0)
		{
			return false;
		}
		else
		{
			goto loop;
		}
	}
}

int main()
{
	int num;
	func(num);
	return 0;
}
