// Access private data members using inheritance

#include <iostream>

using namespace std;

class first
{
        private:
                int a;
        protected:
                int p;
        public:
                void get_a(int a){
                        this->a=a;
                }
                void put_a(){
                        cout<<"a="<<a<<endl;
                }
};

class second: public first
{
        private:
                int b;
        public:
                void get_b(int b){
                        this->b=b;
                }
                void get_p(int p){
                        this->p=p;
                }
                void put_b(){
                        cout<<"b="<<b<<endl;
                }               
                void put_p(){
                        cout<<"p="<<p<<endl;
                }               
};
int main(){
        
        second obj;
        
        obj.get_a(10);
        obj.get_b(20);
        obj.get_p(30);
        
        obj.put_a();
        obj.put_b();
        obj.put_p();
        
        return 0;
}
