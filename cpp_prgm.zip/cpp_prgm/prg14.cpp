//program of multilevel inheriting method

#include <iostream>

using namespace std;

class animal
{
	public:
	void eat()
	{
		cout<<"Eating"<<endl;
	}
};

class dog:public animal
{
	public:
	void bark()
	{
		cout<<"Barking"<<endl;
	}
};

class babydog:public dog
{
	public:
	void run()
	{
		cout<<"Running"<<endl;
	}
};

int main()
{
	babydog d1;
	d1.eat();
	d1.bark();
	d1.run();
	return 0;
}
