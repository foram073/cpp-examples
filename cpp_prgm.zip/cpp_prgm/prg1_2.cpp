#include <iostream>

using namespace std;

int main()
{
	char a = 'A';
	bool b = true;
	double c = 90.09;
	
	cout <<"char value " <<a <<endl;
	cout <<std::boolalpha <<"bool value " <<b <<endl;
	cout <<"double value " <<c <<endl;
	return 0;
}
