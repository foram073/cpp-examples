//program of single level inheritance

#include <iostream>

using namespace std;

class employee
{
	public:
	float salary;
};

class account:public employee
{
	public:
	float bonus;
};

int main()
{
	account acc;
	acc.bonus = 20000;
	acc.salary = 60000;
	cout<<"salary is "<<acc.salary<<endl;
	cout<<"bonus is "<<acc.bonus<<endl;
	return 0;
}
