//program of multiple inheritance

#include <iostream>

using namespace std;

class first
{
	protected:
	int a;
	public:
	void get_a(int n)
	{
		a = n;
	}
};

class second
{
	protected:
	int b;
	public:
	void get_b(int n)
	{
		b = n;
	}
};

class third:public first,public second
{
	public:
	void display()
	{
		cout<<"The value of a is "<<a<<endl;
		cout<<"The value of b is "<<b<<endl;
		cout<<"The addition is "<<a+b<<endl;
	}
};

int main()
{
	third c;
	c.get_a(10);
	c.get_b(20);
	c.display();
	return 0;
}
