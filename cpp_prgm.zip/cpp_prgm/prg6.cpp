#include <iostream>

using namespace std;

class employee
{
	public:
	employee()
	{
		cout <<"Default constructor invoked" <<endl;
	}
};

int main()
{
	employee emp1;
	employee emp2;
	return 0;
}
