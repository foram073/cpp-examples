// Program of abstraction

#include <iostream>  

using namespace std;  

class shape    
{    
	public:   
	virtual void draw()=0;    
};    

class triangle : shape    
{    
	public:  
	void draw()    
	{    
		cout <<"drawing triangle" <<endl;    
	}    
};    

class square : shape    
{    
	public:  
	void draw()    
	{    
            cout <<"drawing square" <<endl;    
	}    
};    

int main( ) 
{  
	triangle tri;  
	square sq;  
	tri.draw();    
	sq.draw();   
	return 0;  
}  
