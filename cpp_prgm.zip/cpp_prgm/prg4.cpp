#include <iostream>  

using namespace std; 
 
class student
{  
	public:  
	int id;      
	string name;      
	void insert(int i, string n)    
	{    
		id = i;    
		name = n;    
	}    
	void display()    
	{    
		cout<<id<<"  "<<name<<endl;    
	}    
};  
int main(void) 
{  
	student stud1;    
	student stud2;  
	stud1.insert(101, "abcde");    
	stud2.insert(102, "xyzw");    
	stud1.display();    
	stud2.display();  
	return 0;  
}  
