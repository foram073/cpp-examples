#include <iostream>
#include <string>

using namespace std;

class animal
{
	protected:
	int age;
	string name;
	
	public:
	void set_value(int a, string n)
	{
		age = a;
		name = n;
	}
};

class zebra: public animal
{
	public:
	void msg()
	{
		cout<<"The zebra named "<<name<<" is "<<age<<" years old and the place of origin is Africa "<<endl;
	}
};

class dolphin: public animal
{
	public:
	void msg()
	{
		cout<<"The dolphin named "<<name<<" is "<<age<<" years old and the place of origin is southern Australia "<<endl;
	}
};

int main()
{
	zebra zeb;
	dolphin dol;
	string n1 = "Anna";
	string n2 = "Jenna";

	zeb.set_value (20,n1);
	dol.set_value (10,n2);

	zeb.msg() ;
	dol.msg() ;
	return 0;
}
