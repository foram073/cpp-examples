// Program of encapsulation

#include<iostream>

using namespace std;
  
class encap
{
	private:
	int x;
          
	public:
	void set(int val)
	{
            x = val;
        }
          
	int get()
        {
            return x;
        }
};
  
int main()
{
    encap obj;
      
    obj.set(50);
      
    cout<<obj.get()<<endl;
    return 0;
}
