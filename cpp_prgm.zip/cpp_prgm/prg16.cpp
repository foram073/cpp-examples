//Program of hybrid inheritance

#include <iostream>

using namespace std;

class first
{
	protected:
	int a;
	public:
	void get_a()
	{
		cout<<"Enter the value of a "<<endl;
		cin>>a;
	}
};

class second:public first
{
	protected:
	int b;
	public:
	void get_b()
	{
		cout<<"Enter the value of b "<<endl;
		cin>>b;
	}
};

class third
{
	protected:
	int c;
	public:
	void get_c()
	{
		cout<<"Enter the value of c "<<endl;
		cin>>c;
	}
};

class fourth:public second,public third
{
	public:
	void mul()
	{
		get_a();
		get_b();
		get_c();
		cout<<"Multiplication is "<<a*b*c<<endl;
	}
};

int main()
{
	fourth d;
	d.mul();
	return 0;
}



