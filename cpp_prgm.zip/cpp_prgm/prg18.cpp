// Program on function overloaading of compile time polymorphism 

#include <iostream>
    
using namespace std;    

class cal 
{    
	public:    
	static int add(int x,int y)
	{      
		return x + y;      
	}      
	static int add(int x, int y, int z)      
	{      
		return x + y + z;      
	}      
};     

int main(void) 
{    
	cal c;                                                     
	cout<<c.add(10, 20)<<endl;      
	cout<<c.add(12, 20, 23)<<endl;     
	return 0;    
} 
