// Program of dynamic memory allocation

#include <iostream>

using namespace std; 

int main()
{
	double* value = NULL;
	value = new double;
	*value = 30000.26;
	cout << "Value is : " << *value << endl;
	delete value;
}
