// Program on operator overloaading of compile time polymorphism 

#include <iostream>

using namespace std;

class box 
{
	public:
	double getvolume(void) 
	{
		return length * breadth * height;
	}
	void setlength( double len ) 
	{
		length = len;
	}
	void setbreadth( double brea ) 
	{
		breadth = brea;
	}
	void setheight( double hei ) 
	{
		height = hei;
	}
      
	box operator+(const box& b) 
	{
		box b1;
		b1.length = this->length + b.length;
		b1.breadth = this->breadth + b.breadth;
		b1.height = this->height + b.height;
		return b1;
	}
      
	private:
	double length;      
	double breadth;    
	double height;      
};

int main() 
{

	box box1;               
	box box2;                
	box box3;                
	double volume = 0.0;     
   
	box1.setlength(9.0); 
	box1.setbreadth(10.0); 
	box1.setheight(7.0);
   
	box2.setlength(8.0); 
	box2.setbreadth(10.0); 
	box2.setheight(6.0);
 
	volume = box1.getvolume();
	cout << "Volume of box1 : " << volume <<endl;
 
	volume = box2.getvolume();
	cout << "Volume of box2 : " << volume <<endl;
   
	box3 = box1 + box2;

	volume = box3.getvolume();
	cout << "Volume of box3 : " << volume <<endl;

	return 0;
}
