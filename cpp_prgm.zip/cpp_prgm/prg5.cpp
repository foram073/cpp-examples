#include <iostream>

using namespace std;

class employee
{
	public:
	int id;
	string name;
	float salary;
	
	void insert(int i, string n, float s)
	{
		id = i;
		name = n;
		salary = s;
	}
	void display()
	{
		cout <<id <<" " <<name <<" " <<salary <<endl;
	}
};

int main()
{
	employee emp1;
	employee emp2;
	emp1.insert(101,"abcd",24000);
	emp2.insert(201,"opqr",35000);
	emp1.display();
	emp2.display();
	return 0;
}
