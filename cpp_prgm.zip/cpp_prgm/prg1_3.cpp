#include <iostream>

using namespace std;

int main()
{
	int num1, num2;
	int sum, mul;
	cout <<"Enter first number ";
	cin >> num1;
	cout <<"Enter second number ";
	cin >> num2;
	sum = num1 + num2;
	cout << "sum is "<<sum <<endl;
	mul = num1 * num2;
	cout <<"multiplication is "<<mul <<endl;
	return 0;
}
