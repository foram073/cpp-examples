//program of parameterized constructor

#include <iostream>

using namespace std;

class line
{
	private:
	double length;
	public:
	line(double len);
	double getlength(void);
	void setlength(double len);
};
line::line(double len)
{
	cout<<"object is being created length = "<<len<<endl;
	length = len;
}
void line::setlength(double len)
{
	length = len;
}
double line::getlength()
{
	return length;
}

int main()
{
	line l1(9.0);
	cout<<"lenght of line = "<<l1.getlength()<<endl;
	l1.setlength(18);
	cout<<"length of line = "<<l1.getlength()<<endl;
	return 0;
}
