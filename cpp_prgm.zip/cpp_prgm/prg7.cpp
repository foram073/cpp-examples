// program of default constructor

#include <iostream>

using namespace std;

class line
{
	private:
	double length;
	public:
	double getlength();
	void setlength(double len);
	line()
	{
		cout<<"object is being created"<<endl;
	}
};

double line::getlength()
{
	return length;
}

void line::setlength(double len)
{
	length = len;
}

int main()
{
	line l1;
	l1.setlength(10.0);
	cout<<"length is "<<l1.getlength()<<endl;
	return 0;
}
