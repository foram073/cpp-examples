//program of multiple inheritance

#include <iostream>

using namespace std;

class shape	//base class
{
	protected:
	int height;
	int width;
	public:
	void setheight(int h)
	{
		height = h;
	}
	void setwidth(int w)
	{
		width = w;
	}
};

class cost	//base class
{
	public:
	int getcost(int area)
	{
		return (area * 80);
	}
};

class rectangle:public shape,public cost	//derived class (multiple inheritance)
{
	public:
	int getarea()
	{
		return (height * width);
	}
};

int main()
{
	rectangle rect;	//object of derived class
	int area;
	
	rect.setwidth(8);
	rect.setheight(10);
	
	area = rect.getarea();
	
	cout<<"total area is "<<rect.getarea()<<endl;
	cout<<"total cost is "<<rect.getcost(area)<<endl;
	return 0;
}
